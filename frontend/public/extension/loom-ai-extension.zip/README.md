# Loom AI - VS Code Extension

Import projects from Loom AI directly into VS Code with one click.

## Features

- 🚀 **One-Click Import**: Import Loom projects directly into VS Code
- 📦 **Auto Setup**: Automatically clones repo and installs dependencies
- 🔔 **Notifications**: Get notified when new projects are ready
- ⚡ **Status Bar**: See pending projects at a glance

## Installation

1. Install from VS Code Marketplace (coming soon)
2. Or install from VSIX file

## Usage

### Configure API Key

1. Open Command Palette (`Ctrl+Shift+P` or `Cmd+Shift+P`)
2. Run `Loom: Configure API Key`
3. Enter your Loom AI API key

### Import a Project

1. Export a project from Loom AI web app
2. Click the Loom icon in the status bar
3. Select the project to import
4. Wait for automatic setup
5. Start coding!

## Settings

- `loom.apiKey`: Your Loom AI API key
- `loom.apiUrl`: Loom AI API URL (default: http://localhost:3000)
- `loom.projectsDirectory`: Directory where projects will be cloned (default: ~/loom-projects)

## Requirements

- Git must be installed and available in PATH
- Node.js and npm (or yarn/pnpm) for dependency installation

## Development

```bash
cd loom-vscode-extension
npm install
npm run compile
```

Press F5 to open a new VS Code window with the extension loaded.

## License

MIT
