import * as vscode from 'vscode';
import { randomUUID } from 'crypto';
import axios from 'axios';
import { CommandExecutor, Command } from './services/commandExecutor';
import { SyncService } from './services/syncService';

let statusBarItem: vscode.StatusBarItem;
let pollInterval: NodeJS.Timeout | undefined;
let deviceId: string;

export function activate(context: vscode.ExtensionContext) {
    console.log('Loom AI Command Extension is now active!');

    // Get or create device ID
    deviceId = context.globalState.get('deviceId') || randomUUID();
    context.globalState.update('deviceId', deviceId);

    // Create status bar item
    statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
    statusBarItem.text = "$(sync~spin) Loom: Connecting...";
    statusBarItem.tooltip = "Loom is connecting to the gateway...";
    statusBarItem.show();
    context.subscriptions.push(statusBarItem);

    // Register device on activation
    registerDevice().then(() => {
        statusBarItem.text = "$(cloud) Loom";
        statusBarItem.tooltip = "Loom: Connected";

        // Start polling for commands
        startCommandPolling();

        // Start real-time sync
        startSyncService();
    }).catch((error) => {
        statusBarItem.text = "$(cloud-offline) Loom";
        statusBarItem.tooltip = `Loom: Connection failed - ${error.message}`;
        vscode.window.showErrorMessage(`Failed to register with Loom: ${error.message}`);
    });

    // Register commands
    const configureCommand = vscode.commands.registerCommand('loom.configure', async () => {
        await configureApiKey();
    });

    context.subscriptions.push(configureCommand);

    // Register URI Handler for Authentication
    // loom.extension://auth?token=xyz
    const uriHandler = vscode.window.registerUriHandler({
        handleUri(uri: vscode.Uri): vscode.ProviderResult<void> {
            if (uri.path === '/auth') {
                const query = new URLSearchParams(uri.query);
                const token = query.get('token');
                if (token) {
                    vscode.workspace.getConfiguration('loom').update('apiKey', token, vscode.ConfigurationTarget.Global);
                    vscode.window.showInformationMessage('Loom AI: Authenticated successfully! Connecting...');

                    // Trigger registration and sync
                    registerDevice().then(() => {
                        vscode.window.showInformationMessage('Loom AI: Extension connected!');
                        startCommandPolling();
                        startSyncService();
                    }).catch(err => {
                        vscode.window.showErrorMessage(`Loom AI: Connection failed - ${err.message}`);
                    });
                }
            }
        }
    });
    context.subscriptions.push(uriHandler);
}

async function registerDevice(): Promise<void> {
    const config = getConfig();
    if (!config.apiKey) {
        throw new Error('API key not configured. Run "Loom: Configure API Key"');
    }

    try {
        await axios.post(`${config.apiUrl}/api/devices/register`, {
            device_id: deviceId,
            ide_type: 'vscode',
            device_name: vscode.env.machineId || 'VSCode',
            metadata: {
                vscode_version: vscode.version,
                platform: process.platform
            }
        }, {
            headers: { Authorization: `Bearer ${config.apiKey}` }
        });

        console.log('Device registered successfully');
    } catch (error) {
        console.error('Device registration failed:', error);
        throw error;
    }
}

function startCommandPolling() {
    pollInterval = setInterval(async () => {
        await pollAndExecuteCommands();
    }, 10000); // Poll every 10 seconds

    // Immediate first poll
    pollAndExecuteCommands();
}

async function pollAndExecuteCommands(): Promise<void> {
    const config = getConfig();
    if (!config.apiKey) {
        return;
    }

    try {
        const response = await axios.get(`${config.apiUrl}/api/commands/poll`, {
            params: { device_id: deviceId, limit: 5 },
            headers: { Authorization: `Bearer ${config.apiKey}` }
        });

        const commands: Command[] = response.data.commands || [];

        if (commands.length > 0) {
            statusBarItem.text = `$(sync~spin) Loom (${commands.length})`;
            statusBarItem.tooltip = `Executing ${commands.length} command(s)...`;

            const executor = new CommandExecutor();

            for (const command of commands) {
                try {
                    await executor.execute(command);
                } catch (error) {
                    console.error('Command execution failed:', error);
                }
            }

            statusBarItem.text = "$(cloud) Loom";
            statusBarItem.tooltip = "Loom: Connected";
        }
    } catch (error) {
        console.error('Polling error:', error);
        statusBarItem.text = "$(cloud-offline) Loom";
        statusBarItem.tooltip = "Loom: Connection error";
    }
}

async function configureApiKey() {
    const apiKey = await vscode.window.showInputBox({
        prompt: 'Enter your Loom AI API key',
        password: true,
        placeHolder: 'loom_xxxxxxxxxxxxx'
    });

    if (apiKey) {
        await vscode.workspace.getConfiguration('loom').update('apiKey', apiKey, vscode.ConfigurationTarget.Global);
        vscode.window.showInformationMessage('Loom AI API key configured successfully! Reloading...');

        // Re-register device and start polling
        await registerDevice();
        if (!pollInterval) {
            startCommandPolling();
        }
    }
}

function getConfig() {
    const config = vscode.workspace.getConfiguration('loom');
    return {
        apiKey: config.get<string>('apiKey') || '',
        apiUrl: config.get<string>('apiUrl') || 'http://localhost:4000'
    };
}

let syncService: SyncService | undefined;

async function startSyncService() {
    const config = getConfig();
    if (config.apiKey) {
        if (syncService) {
            syncService.dispose();
        }
        // deviceId global var from activation
        syncService = new SyncService(config.apiKey, deviceId, config.apiUrl);
    }
}

export function deactivate() {
    if (pollInterval) {
        clearInterval(pollInterval);
    }
    if (syncService) {
        syncService.dispose();
    }
}
